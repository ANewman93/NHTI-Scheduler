==========================================================================================================
HOW TO USE NHTI SCHEDULER:                                                                               |
NOTE:                                                                                                          |
==========================================================================================================
FILE MENU                                                                                                |
----------------------------------------------------------------------------------------------------------
Open Course File: Opens the daily tally file for schedule creation. Drag to over the schedule to add.    |
                                                                                                         |
Print: Prints a blank or created schedule to printer or, if available, to PDF.                           |
                                                                                                         |
Close: Another way to close the tool.                                                                    |
                                                                                                         |
                                                                                                         |
                                                                                                         |
==========================================================================================================
COURSE OPTIONS MENU                                                                                      |
----------------------------------------------------------------------------------------------------------
Filter Courses: Allows you to filter courses by number of students remaining, or day available.          |
                                                                                                         |
                                                                                                         |
                                                                                                         |
==========================================================================================================
SCHEDULE OPTIONS MENU                                                                                    |   
----------------------------------------------------------------------------------------------------------
Open Existing Schedule: Opens existing schedule and places courses and custom blocks on to the schedule. |
                                                                                                         |
Save Existing Schedule: Saves scheduler to location of your choosing for later access.                   |
                                                                                                         |
Clear Schedule: Clear all custom blocks and courses from the schedule to start from scratch.             |
                                                                                                         |
                                                                                                         |
                                                                                                         |
==========================================================================================================
CUSTOM BLOCKS                                                                                            |
----------------------------------------------------------------------------------------------------------
Add Custom Block: Double click on an empty time slot.                                                    |
                                                                                                         |
Resize Custom Block: Pull down or up from the bottom of the block.                                       |
                                                                                                         |
Delete Custom Block: Hover over the top right corner of the block and an X will appear. Click that X.    |
                                                                                                         |
Filling in Custom Block: A total of 9 lines of text can be added by clicking and typing.                 | 
                                                                                                         |
                                                                                                         |
                                                                                                         |
==========================================================================================================
OTHER FUNCTIONS                                                                                          |
----------------------------------------------------------------------------------------------------------
1. Click on courses to highlight all courses for that course number.                                     |
2. Right click for a delete button to show up. This allows you to remove individual courses.             |
                                                                                                         |
                                                                                                         |
==========================================================================================================